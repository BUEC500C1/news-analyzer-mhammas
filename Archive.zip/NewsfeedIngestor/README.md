
# NewsFeed Ingestor

## API Type

Procedural

## Purpose

An API to discover news content on the internet (e.g. looking for Super bowl). It supports searching by keyword.

## Implementation Details

- The function ``search_by_keyword(keyword)`` in ``ingestor.py`` takes in a keyword argument to search the internet for related articles
