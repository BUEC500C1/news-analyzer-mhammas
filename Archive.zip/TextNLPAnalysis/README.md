
# Text NLP Analysis

## API Type

Procedural

## Purpose

An API to perform nlp analysis (e.g. sentiment analysis) on a given text.

## Implementation Details

- The function ``get_sentiment(text)`` in ``nlp.py`` takes in text and returns the sentiment score for it
